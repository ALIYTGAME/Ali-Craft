package ru.alicraft.launcher

import org.junit.Assert.assertEquals
import org.junit.Test

class UtilTest {
    @Test fun ramIsCappedToHalf() = assertEquals(3, clampRam(8, 6))
    @Test fun ramMinimumIsOne() = assertEquals(1, clampRam(1, 1))
    @Test fun fpsPresetIsLighter() = assertEquals(2, presetFor("FPS").ramGb)
}
