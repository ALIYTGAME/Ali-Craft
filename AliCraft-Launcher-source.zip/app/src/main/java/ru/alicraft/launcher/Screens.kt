@file:OptIn(ExperimentalMaterial3Api::class)
package ru.alicraft.launcher

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) = Card(
    Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }

@Composable
fun Title(t: String) = Text(t, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

@Composable
fun HomeScreen(s: Settings, goto: (String) -> Unit) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("Игровой движок: не подключён") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("AliCraft Launcher", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Маленький лаунчер. Большие возможности.", color = MaterialTheme.colorScheme.secondary)
        Panel {
            Text("Версия Minecraft Java", fontWeight = FontWeight.SemiBold)
            Text(if (s.version.isBlank()) "не выбрана" else s.version, fontSize = 22.sp)
            OutlinedButton(onClick = { goto("versions") }) { Text("Выбрать версию") }
            Button(onClick = {
                msg = if (s.version.isBlank()) "Сначала выберите версию."
                else "Запуск невозможен: игровой движок (PojavLauncher-основа) ещё не интегрирован. Это MVP-оболочка."
            }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("▶  Играть", fontSize = 20.sp) }
            Text(msg, color = MaterialTheme.colorScheme.secondary)
        }
        Panel {
            Text("Профиль: ${s.profile}", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Balanced", "FPS", "Modded").forEach {
                    FilterChip(selected = s.profile == it, onClick = { s.applyPreset(it, totalRamGb(ctx)) }, label = { Text(it) })
                }
            }
            Text("ОЗУ: ${s.ram} ГБ • Разрешение: ${s.scale}% • Дальность: ${s.dist}")
        }
        Panel {
            Text("Статус", fontWeight = FontWeight.SemiBold)
            Text("• Список версий и каталог Modrinth — код есть (нужен интернет)")
            Text("• Установка версий, запуск игры, рендереры, вход Microsoft — не реализованы")
        }
    }
}

@Composable
fun VersionsScreen(s: Settings) {
    var list by remember { mutableStateOf<List<Net.MC>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var type by remember { mutableStateOf("release") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        err = null; list = null
        try { list = Net.versions() } catch (e: Exception) { err = e.message ?: e.toString() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Title("Версии Minecraft Java")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("release", "snapshot", "old_beta").forEach {
                FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) })
            }
        }
        Text("Выбрано: ${s.version.ifBlank { "—" }}. Скачивание файлов игры пока не реализовано.",
            color = MaterialTheme.colorScheme.secondary)
        val l = list
        when {
            err != null -> {
                Text("Не удалось загрузить список: $err", color = MaterialTheme.colorScheme.error)
                Button(onClick = { reload++ }) { Text("Повторить") }
            }
            l == null -> CircularProgressIndicator()
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(l.filter { it.type == type }) { v ->
                    Panel { Text(v.id, fontSize = 18.sp, modifier = Modifier.fillMaxWidth()
                        .clickable { s.version = v.id; s.save() }) }
                }
            }
        }
    }
}

@Composable
fun ModsScreen(s: Settings) {
    var q by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("mod") }
    var loader by remember { mutableStateOf("fabric") }
    var go by remember { mutableIntStateOf(0) }
    var res by remember { mutableStateOf<List<Net.Proj>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(go) {
        if (go == 0) return@LaunchedEffect
        busy = true; err = null
        try { res = Net.search(q, type, s.version, loader) } catch (e: Exception) { err = e.message ?: e.toString() }
        busy = false
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Title("Каталог Modrinth")
        OutlinedTextField(q, { q = it }, label = { Text("Поиск") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("mod", "modpack", "resourcepack", "shader").forEach {
                FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it, fontSize = 12.sp) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("fabric", "forge", "neoforge", "quilt").forEach {
                FilterChip(selected = loader == it, onClick = { loader = it }, label = { Text(it, fontSize = 12.sp) })
            }
        }
        Text("Фильтр версии: ${s.version.ifBlank { "любая" }}", color = MaterialTheme.colorScheme.secondary)
        Button(onClick = { go++ }) { Text("Искать") }
        if (busy) CircularProgressIndicator()
        err?.let { Text("Ошибка: $it", color = MaterialTheme.colorScheme.error) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(res ?: emptyList()) { p ->
                Panel {
                    Text(p.title, fontWeight = FontWeight.Bold)
                    Text("от ${p.author} • ${p.downloads} загрузок", fontSize = 12.sp)
                    Text(p.desc, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun SkinsScreen() {
    val ctx = LocalContext.current
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var note by remember { mutableStateOf("Выберите PNG-скин 64×64 или 64×32.") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val b = try { ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
            if (b == null) note = "Не удалось прочитать файл."
            else if (b.width != 64 || (b.height != 64 && b.height != 32)) note = "Нужен PNG 64×64 или 64×32."
            else { bmp = b; note = "Это только ЛОКАЛЬНЫЙ просмотр. В игру скин не применён." }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Скины")
        Button(onClick = { pick.launch("image/png") }) { Text("Выбрать PNG") }
        Text(note, color = MaterialTheme.colorScheme.secondary)
        bmp?.let { b ->
            val img = remember(b) { b.asImageBitmap() }
            Canvas(Modifier.size(160.dp)) {
                val px = size.width.toInt()
                drawImage(img, IntOffset(8, 8), IntSize(8, 8), IntOffset.Zero, IntSize(px, px), filterQuality = FilterQuality.None)
                drawImage(img, IntOffset(40, 8), IntSize(8, 8), IntOffset.Zero, IntSize(px, px), filterQuality = FilterQuality.None)
            }
            Text("Предпросмотр головы (лицо + слой шапки)")
        }
    }
}

@Composable
fun WorldsScreen() {
    val ctx = LocalContext.current
    val dir = File(ctx.getExternalFilesDir(null), "minecraft/saves")
    val worlds = dir.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Title("Миры")
        Text("Папка: ${dir.path}", fontSize = 12.sp)
        if (worlds.isEmpty()) Text("Миров не найдено. Импорт, экспорт и резервные копии появятся после интеграции движка.")
        worlds.forEach { Panel { Text(it) } }
    }
}

@Composable
fun SettingsScreen(s: Settings) {
    val ctx = LocalContext.current
    val total = totalRamGb(ctx)
    val maxRam = maxOf(1, total / 2)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Настройки производительности")
        Text("ОЗУ устройства: ~$total ГБ. Максимум для игры: $maxRam ГБ.")
        Panel {
            Text("Память: ${s.ram} ГБ")
            if (maxRam > 1) Slider(s.ram.toFloat(), { s.ram = clampRam(it.toInt(), total) },
                valueRange = 1f..maxRam.toFloat(), steps = maxOf(0, maxRam - 2), onValueChangeFinished = { s.save() })
        }
        Panel {
            Text("Разрешение: ${s.scale}%")
            Slider(s.scale.toFloat(), { s.scale = it.toInt() }, valueRange = 50f..100f, onValueChangeFinished = { s.save() })
        }
        Panel {
            Text("Дальность прорисовки: ${s.dist}")
            Slider(s.dist.toFloat(), { s.dist = it.toInt() }, valueRange = 2f..16f, steps = 13, onValueChangeFinished = { s.save() })
        }
        Panel {
            Text("Рендерер", fontWeight = FontWeight.SemiBold)
            Text("Пока не подключён. GL4ES / VirGL / Zink / Vulkan будут добавлены после интеграции основы и проверки на ARM64.")
            Text("Значения выше сохраняются, но пока не влияют на игру.", color = MaterialTheme.colorScheme.secondary)
        }
        Panel {
            Text("О приложении", fontWeight = FontWeight.SemiBold)
            Text("AliCraft Launcher 0.1.0-mvp. Minecraft — торговая марка Mojang/Microsoft. Не является официальным продуктом.")
        }
    }
}
