package ru.alicraft.launcher

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp

private val Cyan = Color(0xFF22D3EE)
private val Bg = Color(0xFF050B1F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, onPrimary = Bg, background = Bg, surface = Color(0xFF0B1632),
                onSurface = Color(0xFFE6F1FF), onBackground = Color(0xFFE6F1FF),
                secondary = Color(0xFF2DD4BF), surfaceVariant = Color(0xFF0E1D3D))) {
                App()
            }
        }
    }
}

fun totalRamGb(ctx: Context): Int {
    val mi = ActivityManager.MemoryInfo()
    (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    return (mi.totalMem / (1024L * 1024 * 1024)).toInt()
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val s = remember { Settings(ctx) }
    var screen by remember { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }
    val tabs = listOf("home" to "🏠 Главная", "versions" to "📦 Версии", "mods" to "🧩 Моды",
        "skins" to "🙂 Скины", "worlds" to "🌍 Миры", "settings" to "⚙️ Опции")
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Color(0xFF0B1632)) {
            tabs.forEach { (id, label) ->
                NavigationBarItem(selected = screen == id, onClick = { screen = id },
                    icon = { Text(label.substringBefore(' ')) },
                    label = { Text(label.substringAfter(' '), fontSize = 9.sp, maxLines = 1) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (screen) {
                "home" -> HomeScreen(s) { screen = it }
                "versions" -> VersionsScreen(s)
                "mods" -> ModsScreen(s)
                "skins" -> SkinsScreen()
                "worlds" -> WorldsScreen()
                else -> SettingsScreen(s)
            }
        }
    }
}
