package ru.alicraft.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    data class MC(val id: String, val type: String)
    data class Proj(val title: String, val author: String, val desc: String, val downloads: Long)

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "AliCraft-Launcher/0.1.0")
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally { c.disconnect() }
    }

    /** Официальный манифест версий Mojang. */
    suspend fun versions(): List<MC> = withContext(Dispatchers.IO) {
        val a = JSONObject(get("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")).getJSONArray("versions")
        List(a.length()) { a.getJSONObject(it).let { o -> MC(o.getString("id"), o.getString("type")) } }
    }

    /** Официальный API Modrinth v2. */
    suspend fun search(q: String, type: String, mc: String, loader: String): List<Proj> = withContext(Dispatchers.IO) {
        val f = JSONArray().put(JSONArray().put("project_type:$type"))
        if (mc.isNotBlank()) f.put(JSONArray().put("versions:$mc"))
        if (loader.isNotBlank() && (type == "mod" || type == "modpack")) f.put(JSONArray().put("categories:$loader"))
        val url = "https://api.modrinth.com/v2/search?limit=20&query=" + URLEncoder.encode(q, "UTF-8") +
            "&facets=" + URLEncoder.encode(f.toString(), "UTF-8")
        val hits = JSONObject(get(url)).getJSONArray("hits")
        List(hits.length()) {
            val o = hits.getJSONObject(it)
            Proj(o.getString("title"), o.optString("author"), o.optString("description"), o.optLong("downloads"))
        }
    }
}
