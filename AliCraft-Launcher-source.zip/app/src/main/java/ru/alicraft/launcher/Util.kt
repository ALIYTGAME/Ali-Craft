package ru.alicraft.launcher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Не больше половины ОЗУ устройства, минимум 1 ГБ. */
fun clampRam(wantGb: Int, totalGb: Int): Int = wantGb.coerceIn(1, maxOf(1, totalGb / 2))

data class Preset(val ramGb: Int, val scalePct: Int, val renderDist: Int)

fun presetFor(profile: String): Preset = when (profile) {
    "FPS" -> Preset(2, 75, 6)
    "Modded" -> Preset(4, 100, 8)
    else -> Preset(3, 100, 8) // Balanced
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("alicraft", Context.MODE_PRIVATE)
    var version by mutableStateOf(p.getString("version", "") ?: "")
    var profile by mutableStateOf(p.getString("profile", "Balanced") ?: "Balanced")
    var ram by mutableStateOf(p.getInt("ram", 3))
    var scale by mutableStateOf(p.getInt("scale", 100))
    var dist by mutableStateOf(p.getInt("dist", 8))
    fun save() = p.edit().putString("version", version).putString("profile", profile)
        .putInt("ram", ram).putInt("scale", scale).putInt("dist", dist).apply()
    fun applyPreset(name: String, totalGb: Int) {
        val pr = presetFor(name)
        profile = name; ram = clampRam(pr.ramGb, totalGb); scale = pr.scalePct; dist = pr.renderDist; save()
    }
}
