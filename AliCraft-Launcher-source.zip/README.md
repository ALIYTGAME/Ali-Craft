# AliCraft Launcher (MVP)

Android-оболочка на Kotlin + Jetpack Compose. **Игру Minecraft пока не запускает** — движок не интегрирован.

## Как получить APK с телефона (GitHub Actions)
1. Войдите на github.com, создайте репозиторий (New repository).
2. **Add file → Upload files** → загрузите `AliCraft-Launcher-source.zip` одним файлом → Commit.
3. **Add file → Create new file**, имя: `.github/workflows/android.yml` (слэши создадут папки). Вставьте содержимое файла `android.yml` из набора → Commit.
4. Вкладка **Actions** → дождитесь зелёной галочки (5–10 минут). Если не стартовало: «Android build» → **Run workflow**.
5. Откройте запуск → внизу **Artifacts** → `AliCraft-Launcher-apk` → скачайте, распакуйте ZIP, внутри `app-debug.apk`.
6. Установка на OPPO (Android 16): откройте APK из «Файлы», разрешите установку из этого источника. Если Play Protect предупреждает — «Всё равно установить» (APK подписан отладочным ключом).

## Локальная сборка
JDK 17, Android SDK 34, Gradle 8.7: `gradle testDebugUnitTest lintDebug assembleDebug`.
